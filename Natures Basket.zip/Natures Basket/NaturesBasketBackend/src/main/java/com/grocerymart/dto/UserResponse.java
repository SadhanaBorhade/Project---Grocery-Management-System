package com.grocerymart.dto;

public class UserResponse {

}
